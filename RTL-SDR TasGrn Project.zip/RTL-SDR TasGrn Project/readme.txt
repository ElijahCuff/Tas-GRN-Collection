Steps to easily setup and stream 3 Channel Trunked Radio Systems RTL-SDR v3,
Bypassing Trunking by monitoring each voice channel with AuxVFO Plugin for SDRSharp.

- Extract Program Files
- Install VB-Audio Cable ( Virtual Audio Cable )
"\Stream RTL-SDR\VBCABLE_Setup.exe"

- Install RTL-SDR Drivers
"\SDR Sharp Favourite V\zadig.exe"

- Open SDR Sharp and tune to desired channels ( Mt Horror, Tas - Default )

- Edit AUX VFO Plugin to include listeners on each channel within the sample rate 2.56MSPS or upwards,
"\SDR Sharp Favourite V\AuxVFOSettings1"
"\SDR Sharp Favourite V\AuxVFOSettings2"
"\SDR Sharp Favourite V\AuxVFOSettings3"
"\SDR Sharp Favourite V\Plugins.xml"



STREAM
- create 400 free listener stream account at http://caster.fm
- get stream details from caster account
- open AltaCast Standalone
"\Stream RTL-SDR\altacastStandalone.exe"

- add Encoder with details from caster.fm
- set stream encoder type to MP3 Lame
- set stream server type to Icecast 2
- set Audio Source to VB-Audio Virtual Cable ( Virtual Microphone Feed )

- open SDR Sharp and set Aux VFO Plugins to output to CABLE Input (VB-Audio Virtual Cable) 
( allowing the software to play audio as a microphone for input to AltaCast )

Start Streaming (->_<-) !!!

 
To Listen To the Virtual Microphone Feed, Open Windows Sound Control Panel and navigate to the microphone tab, open the properties for VB-Audio Virtual Cable and enable "Listen to this device" - now you can listen and stream simultaneously without other PC Audio ruining the stream.






